# VEYRON SMP Halloween Scoreboard Resource Pack

This resource pack adds private-use Unicode bitmap glyphs to Minecraft's default font.

## Install / GitHub
1. Create a PUBLIC GitHub repository and upload the ZIP file (recommended: GitHub Releases as an asset).
2. Copy the direct release-asset URL. A GitHub repository page URL is NOT a resource-pack download URL.
3. Set `resource-pack=<direct ZIP URL>` in `server.properties`. Optionally set `require-resource-pack=true`.
4. Restart your server and accept the resource pack in Minecraft.
5. To verify, use `/tellraw @s {"text":"\\uE001 Rank"}` (if server supports vanilla JSON). E001 already includes the Rank label? No: E001 = Tag, E002 = Rank.
   Example: `/tellraw @s {"text":"\\uE002"}`.

## Glyphs
E000 frame (large image)
E001 Tag
E002 Rank
E003 Money
E004 Gems
E005 Kills
E006 Deaths
E007 Invest
E008 Playtime
E009 Team
E00A Server / IP
E011-E01A = corresponding icons without labels.

## Important
- The frame is a very tall font glyph. Vanilla sidebar scoreboards cannot reliably layer this behind multiple independently positioned text lines. Use a scoreboard plugin that supports custom image glyphs and spacing/offsets, or display the frame using a separate compatible HUD system.
- The frame graphic is reduced to a 180x220 bitmap glyph for Minecraft, but a larger source was used.
- Dynamic values (player name, ranks, money, gems, etc.) require your scoreboard plugin and PlaceholderAPI or Skript integration.
- The frame originated from generated art with a baked checkerboard background; background removal is automated and may need a little pixel cleanup.
- Pack format compatibility depends on your precise Minecraft version. For 1.21.11, verify the resource pack version if Minecraft reports incompatibility.
